package model;

/**
 * 
 */
public class Board {

	private Item[][] maze;
	public Item m_Item;

	public Board(){

	}

	public void finalize() throws Throwable {

	}
	/**
	 * 
	 * @param maze
	 */
	public void setMaze(Item[][] maze){

	}

	public Item getItem(){
		return null;
	}
}//end Board