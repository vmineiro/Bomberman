package model;

/**
 * 
 */
public class Monster1 extends Monster {

	public Monster1(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
	/**
	 * 
	 * @param state
	 */
	public void setCurrentState(MonsterState state){

	}

	public void draw(){

	}

	public void update(){

	}

	/**
	 * 
	 * @param animation
	 */
	public void setAnimation(/*Animation animation*/){

	}
}//end Monster1