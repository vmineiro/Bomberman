package model;

/**
 * 
 */
public class AutomaticBomb extends Bomb {

	private int timeOut = 5;

	public AutomaticBomb(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
	public void countDown(){

	}

	public void detonate(){

	}
}//end AutomaticBomb