package model;

/**
 * 
 */
public class Monster2 extends Monster {

	public Monster2(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
	/**
	 * 
	 * @param state
	 */
	public void setCurrentState(MonsterState state){

	}

	public void draw(){

	}

	public void update(){

	}

	/**
	 * 
	 * @param animation
	 */
	public void setAnimation(/*Animation animation*/){

	}
}//end Monster2