package model;

/**
 * 
 */
public class BoardFactory {

	private Item[][] maze;

	public BoardFactory(){

	}

	public void finalize() throws Throwable {

	}
	public void createExtraBomb(){

	}

	public void createBombControl(){

	}

	public void createBombPowerUp(){

	}

	public void createBoardExit(){

	}

	public void createBoostSpeed(){

	}

	public void initializeBoard(){

	}

	/**
	 * 
	 * @param i
	 * @param j
	 */
	public void tooglePath(int i, int j){

	}

	/**
	 * 
	 * @param i
	 * @param j
	 * @param item
	 */
	public void setItem(int i, int j, Item item){

	}
}//end BoardFactory