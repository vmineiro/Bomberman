package model;

/**
 * 
 */
public class Bomb {

	private int power;

	public Bomb(){

	}

	public void finalize() throws Throwable {

	}
	public void detonate(){

	}

	public void update(){

	}

	public void draw(){

	}

}//end Bomb