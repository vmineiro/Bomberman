package model;

/**
 * 
 */
public class Position {

	public Position(){

	}

	public void finalize() throws Throwable {

	}
}//end Position