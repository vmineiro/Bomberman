package model;

/**
 * @author VitorHugo
 * @version 1.0
 * @created 23-May-2014 17:56:18
 */
public class Monster3 extends Monster {

	public Monster3(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
	/**
	 * 
	 * @param state
	 */
	public void setCurrentState(MonsterState state){

	}

	public void draw(){

	}

	public void update(){

	}

	/**
	 * 
	 * @param animation
	 */
	public void setAnimation(/*Animation animation*/){

	}
}//end Monster3