package model;

/**
 * 
 */
public class ManualBomb extends Bomb {

	public ManualBomb(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
	public void detonate(){

	}
}//end ManualBomb