package tests;

import org.junit.Test;

/**
 * The Class MonsterTests.
 *
 */
public class MonsterTests {



	/**
	 * Move tests.
	 * 
	 * Neste teste pretende-se testar as movimentações dos tipos de monstros, incluindo colisões contra as paredes, bombas. 
	 */
	@Test
	public void moveTests(){

	}

	/**
	 * Power up tests.
	 * 
	 * Neste teste pretende-se testar as alterações de estado dos tipos de monstros,
	 * quando visitam uma cas de PowerUp. 
	 */
	@Test
	public void powerUpTests(){

	}

	/**
	 * Death test.
	 * 
	 * Neste teste pretende-se testar a morte dos montros, ser será apenas quando a célula, onde o monstro se situa, explode. 
	 */
	@Test
	public void deathTest(){

	}
}//end MonsterTests